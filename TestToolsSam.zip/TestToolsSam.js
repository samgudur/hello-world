class TestTools { 
  
  static function helloWorld() {
    var str = "Hello World!!";
	return str;
  }

}