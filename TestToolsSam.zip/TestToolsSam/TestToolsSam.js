class TestTools { 
  
  static function helloWorld() {
    var str = "Hello World from branch1 !!";
	return str;
  }

}