class TestTools { 
  
  static function helloWorld() {
    var str = "Hello World from branch2 demo !!";
	return str;
  }

}